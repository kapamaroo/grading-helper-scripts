/* Solution for the Hello Lab */
#include <stdio.h>

int main()
{
    printf("Hello, world\n");
    return 0; /* important to return zero here */
}

